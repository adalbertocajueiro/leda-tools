/**
 * 
 */
package sorting.divideAndConquer;

import sorting.SortingImpl;

public class Quicksort<T extends Comparable<T>> extends SortingImpl<T> {

	
	@Override
	protected void sort(T[] array,int leftIndex, int rightIndex) {
		// TODO Auto-generated method stub

	}

}
