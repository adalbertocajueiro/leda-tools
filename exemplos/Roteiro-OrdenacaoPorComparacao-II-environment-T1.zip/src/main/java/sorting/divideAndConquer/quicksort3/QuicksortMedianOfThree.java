package sorting.divideAndConquer.quicksort3;


import sorting.SortingImpl;

/**
 * The interface describing the algorithm of quicksort median of 3. 
 * The implementation of the algorithm must be in-place!
 */
public class QuicksortMedianOfThree<T extends Comparable<T>> extends SortingImpl<T>{
	public void sort(T[] array, int leftIndex, int rightIndex){
		// TODO Auto-generated method stub
	}
}
