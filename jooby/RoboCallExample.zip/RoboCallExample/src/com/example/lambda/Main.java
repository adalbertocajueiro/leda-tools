package com.example.lambda;

/**
 *
 * @author MikeW
 */
public class Main {

  public static void main(String[] args) {
    
    RoboCallTest01.main(args);
    RoboCallTest02.main(args);
    RoboCallTest03.main(args);
    RoboCallTest04.main(args);
    
  }
}
