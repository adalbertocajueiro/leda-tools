package com.example.lambda;

/**
 * @author MikeW
 */
public interface MyTest<T> {
  public boolean test(T t);
}
