package com.example.lambda;

public interface Predicate<T> {
  public boolean test(T t);
}
