package hellorestful;

import org.junit.Test;

/**
 * @author jooby generator
 */
public class AppTest extends BaseTest {

  @Test
  public void index() throws Exception {
    server.get("/greeting")
        .expect("{\"id\":1,\"name\":\"Hello World!\"}")
        .header("Content-Type", "application/json;charset=UTF-8");
  }

}
