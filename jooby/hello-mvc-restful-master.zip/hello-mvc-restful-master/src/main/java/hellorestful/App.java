package hellorestful;

import org.jooby.Jooby;
import org.jooby.json.Jackson;

public class App extends Jooby {

  {
    use(new Jackson());

    use(Greetings.class);
  }

  public static void main(final String[] args) throws Exception {
    new App().start(args);
  }

}
