package hellorestful;

import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

import org.jooby.mvc.GET;
import org.jooby.mvc.Path;

@Path("/greeting")
public class Greetings {

  private final static AtomicInteger idgen = new AtomicInteger();

  @GET @Path({"/", "/:name" })
  public Greeting salute(final Optional<String> name) {
    return new Greeting(idgen.incrementAndGet(), "Hello " + name.orElse("World") + "!");
  }
}
