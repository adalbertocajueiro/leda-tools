# hello-world

A simple hello world application.

# software requirements
- Java 8.x
- Maven 3.x

# getting started

- fork and clone this repository
- cd ```hellow-world```
- mvn jooby:run
- open a browser at: ```http://localhost:8080```

# need help?
- [Google Group](jooby-project@googlegroups.com)
- [Source Code](https://github.com/jooby-project/jooby)
- [Jooby](http://jooby.org)
