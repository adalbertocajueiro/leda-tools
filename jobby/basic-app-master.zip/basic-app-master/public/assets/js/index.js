(function () {
  console.log('index.js');
})();
