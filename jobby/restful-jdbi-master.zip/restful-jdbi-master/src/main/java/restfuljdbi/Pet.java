package restfuljdbi;

public class Pet {

  private Integer id;

  private String name;

  public Pet() {
  }

  public Integer getId() {
    return id;
  }

  public String getName() {
    return name;
  }

  public void setId(final Integer id) {
    this.id = id;
  }

  public void setName(final String name) {
    this.name = name;
  }

}
